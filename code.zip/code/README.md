# vbiotech

Companion code for the article **"The Company With 37,000 Workers and Zero People: Inside Stanford's AI Biotech That Designed a Cancer Drug."**

Simulations and figures exploring Stanford's Virtual Biotech (Zhang & Zou et al.,
Science 2026): a drug-discovery company staffed by up to 37,000 AI agents.

> **What this is.** Transparent simulations that reproduce the study's key findings
> and explain *why* this agent swarm succeeded where naive agent chains fail. The
> drug-industry baselines (~10% approval, ~5% in oncology) come from published data.

## Quick start

```bash
pip install -r requirements.txt
python -m sim.experiment      # E1 biomarker lift, E2 hierarchy vs chain, E3 speed
python viz/make_figures.py    # the charts
python viz/make_gif.py        # the swarm animation
python viz/cover.py           # the cover
```

## Layout

```
sim/
  screen.py      drug-candidate portfolio model (biomarker-based selection)
  experiment.py  E1 biomarker economics, E2 hierarchy-vs-chain, E3 throughput
viz/
  style.py, make_figures.py, make_gif.py, cover.py
```

## Headline results (from this code)

| Result | Value |
|---|---|
| Portfolio success with AI biomarker (AUC 0.70) | 10% -> 15% (matches the study's "48% more likely to reach market") |
| Cost per approved drug | ~$500M -> ~$335M |
| Naive chain vs verified hierarchy (10 tasks) | 20% vs 94% |
| Trials analyzed: swarm vs one human | 7 days vs ~112 years |

## License

Code: MIT.
