"""
Run the experiments behind the article and save results/vbiotech.json.

E1: The biomarker lift. How selecting candidates on an imperfect AI signal raises
    the portfolio success rate above the brutal ~10% baseline, and what that does
    to cost-per-approved-drug. Reproduces the Virtual Biotech's "48% more likely
    to reach market" finding.

E2: Why a hierarchy beats a chain. The article's intellectual core: a naive agent
    *chain* compounds errors (p^n), but the Virtual Biotech is a *hierarchy* with
    independent specialists plus a verifying manager. We model both and show the
    reliability gap, explaining why this agent swarm succeeded where others fail.

E3: Speed. 55,984 trials analyzed in under a week by agents vs the years a human
    team would need, as a simple throughput comparison.
"""
import json, sys, pathlib
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from sim.screen import ScreenConfig, run, BASE_LOA, BASE_LOA_ONC, COST_PER_PROGRAM

TRIALS = 200


def e1_biomarker():
    aucs = [0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8]
    out = {"auc": aucs, "random": [], "ai": [], "ai_ci": [], "cost_random": [], "cost_ai": []}
    for auc in aucs:
        r_s, a_s, c_r, c_a = [], [], [], []
        for seed in range(TRIALS):
            res = run(ScreenConfig(biomarker_auc=auc, base_rate=BASE_LOA, seed=seed))
            r_s.append(res["random"]["success_rate"])
            a_s.append(res["ai_selected"]["success_rate"])
            c_r.append(res["random"]["cost_per_success"])
            c_a.append(res["ai_selected"]["cost_per_success"])
        out["random"].append(float(np.mean(r_s)))
        out["ai"].append(float(np.mean(a_s)))
        out["ai_ci"].append(float(1.96 * np.std(a_s) / np.sqrt(TRIALS)))
        out["cost_random"].append(float(np.mean(c_r)))
        out["cost_ai"].append(float(np.mean(c_a)))
    return out


def e2_hierarchy_vs_chain():
    """Chain: p^n. Hierarchy: independent specialists, manager verifies & retries."""
    p = 0.85
    steps = list(range(1, 13))
    chain = [p ** n for n in steps]
    # hierarchy: each specialist works independently (its own error doesn't poison
    # the others), and a manager agent verifies each output with 2 retries, so each
    # specialist's effective reliability is ~1-(1-p)^3, then the manager integrates.
    eff = 1 - (1 - p) ** 3
    hierarchy = [eff ** 1 * (0.98 ** 0) for _ in steps]  # placeholder
    # model: hierarchy needs all n specialists to each be individually OK (verified),
    # but NOT chained — so it's eff^n with a much higher eff, plus manager integration 0.97
    hierarchy = [(eff ** n) * 0.97 for n in steps]
    return {"steps": steps, "chain": chain, "hierarchy": hierarchy,
            "per_step_p": p, "verified_eff": eff}


def e3_speed():
    # 55,984 trials in <1 week by agents; human analyst ~ how long?
    trials = 55984
    agent_days = 7
    human_per_trial_hours = 4  # a conservative hour-estimate to read+code one trial
    human_hours = trials * human_per_trial_hours
    human_years = human_hours / (40 * 50)  # 40h/wk, 50 wk/yr, one analyst
    return {"trials": trials, "agent_days": agent_days,
            "human_years_one_analyst": human_years,
            "speedup": human_years * 365 / agent_days}


def main():
    data = {"e1": e1_biomarker(), "e2": e2_hierarchy_vs_chain(), "e3": e3_speed(),
            "baselines": {"loa_all": BASE_LOA, "loa_oncology": BASE_LOA_ONC}}
    (ROOT / "results").mkdir(exist_ok=True)
    json.dump(data, open(ROOT / "results/vbiotech.json", "w"), indent=2)

    e1 = data["e1"]
    i70 = e1["auc"].index(0.7)
    print(f"E1 biomarker (AUC 0.70): {e1['random'][i70]:.1%} -> {e1['ai'][i70]:.1%} "
          f"({e1['ai'][i70]/e1['random'][i70]:.2f}x more approvals)")
    print(f"   cost/approval: ${e1['cost_random'][i70]:.0f}M -> ${e1['cost_ai'][i70]:.0f}M")
    e2 = data["e2"]
    print(f"\nE2 at 10 steps: chain {e2['chain'][9]:.0%} vs hierarchy {e2['hierarchy'][9]:.0%}")
    e3 = data["e3"]
    print(f"\nE3 speed: {e3['trials']:,} trials in {e3['agent_days']} days vs "
          f"{e3['human_years_one_analyst']:.0f} yrs for one human ({e3['speedup']:.0f}x)")


if __name__ == "__main__":
    main()
