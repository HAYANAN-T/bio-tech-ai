"""
sim.screen - a Monte-Carlo model of what the Virtual Biotech's discovery actually
buys you, in the one place it matters most: picking which drug candidates to
advance.

The brutal fact of drug development: only ~10% of candidates that enter Phase I
ever reach the market (worse in oncology, ~5%). Each failed program costs years
and hundreds of millions of dollars. The Virtual Biotech's headline scientific
finding was a *biomarker*: candidates whose target behaves like an on/off switch
and is specific to one cell type were 40% more likely to advance from Phase 1 to
Phase 2, 48% more likely to reach market, and had 32% fewer adverse events.

This module turns that finding into a decision model. We simulate a pipeline of
candidates with a hidden "true" quality, give the AI a noisy biomarker signal
correlated with that quality, and measure how much selecting on the signal
improves the portfolio's success rate and cost-per-success versus selecting at
random (the status quo). It makes concrete *why* a better selection signal, even
an imperfect one, is worth so much in a field with 90% failure.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass

# Industry baselines (sourced in the article):
BASE_LOA = 0.10          # Phase 1 -> approval, all indications (~10%)
BASE_LOA_ONC = 0.053     # oncology Phase 1 -> approval (~5.3%)
COST_PER_PROGRAM = 50.0  # $M of sunk cost to run a candidate through early trials
VALUE_PER_APPROVAL = 1000.0  # $M value of one approved drug (order-of-magnitude)

# The biomarker effect the Virtual Biotech reported:
LIFT_MARKET = 1.48       # 48% more likely to reach market for "switch-like + specific"


@dataclass
class ScreenConfig:
    n_candidates: int = 2000
    base_rate: float = BASE_LOA
    biomarker_auc: float = 0.70   # how well the AI signal separates winners (0.5=useless)
    select_frac: float = 0.3      # advance the top 30% by signal
    seed: int = 0


def _assign_success(n, base_rate, rng):
    """Each candidate has a hidden true success probability; realize an outcome."""
    # heterogeneous true quality (beta around base_rate)
    a = 2.0
    b = a * (1 - base_rate) / base_rate
    true_p = rng.beta(a, b, n)
    success = rng.random(n) < true_p
    return true_p, success


def _biomarker_signal(true_p, auc, rng):
    """A noisy score correlated with true quality, calibrated to a target AUC."""
    # convert desired AUC into a signal-to-noise ratio via a latent-Gaussian model
    # higher auc -> signal tracks true_p more tightly
    z_true = (true_p - true_p.mean()) / (true_p.std() + 1e-9)
    # noise level chosen so ranking quality ~ auc (empirical, good enough for the demo)
    from scipy.stats import norm
    d = np.sqrt(2) * norm.ppf(np.clip(auc, 0.5001, 0.9999))  # separation in SDs
    noise = rng.normal(0, 1, len(true_p))
    return d * z_true + noise


def run(cfg: ScreenConfig):
    rng = np.random.default_rng(cfg.seed)
    true_p, success = _assign_success(cfg.n_candidates, cfg.base_rate, rng)
    signal = _biomarker_signal(true_p, cfg.biomarker_auc, rng)

    n_adv = max(int(cfg.select_frac * cfg.n_candidates), 1)

    # strategy A: random selection (status quo)
    rand_idx = rng.permutation(cfg.n_candidates)[:n_adv]
    rand_success = success[rand_idx].mean()

    # strategy B: select the top candidates by AI biomarker signal
    top_idx = np.argsort(-signal)[:n_adv]
    ai_success = success[top_idx].mean()

    def economics(success_rate):
        approvals = success_rate * n_adv
        spend = COST_PER_PROGRAM * n_adv
        value = VALUE_PER_APPROVAL * approvals
        cost_per_success = spend / max(approvals, 1e-9)
        return dict(success_rate=success_rate, approvals=approvals,
                    cost_per_success=cost_per_success, roi=value / spend)

    return {
        "random": economics(rand_success),
        "ai_selected": economics(ai_success),
        "n_advanced": n_adv,
        "lift": ai_success / max(rand_success, 1e-9),
    }
