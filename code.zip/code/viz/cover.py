"""Cover: the org hierarchy with a swarm of agents, plus title."""
import sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from viz.style import *  # noqa
PURPLE=MIXED; BLUE=RESTRAINED; AIC=GOOD; GOLD=PASSIVE; BASEC=AGGRESSIVE
def main():
    fig=plt.figure(figsize=(8,4.5),facecolor="#F3F6FA")
    fig.text(0.06,0.76,"The company",fontsize=29,fontweight="bold",color=INK,va="center")
    fig.text(0.06,0.66,"with 37,000",fontsize=29,fontweight="bold",color=PURPLE,va="center")
    fig.text(0.06,0.56,"workers, zero people",fontsize=29,fontweight="bold",color=INK,va="center")
    fig.text(0.06,0.40,"Stanford built a drug company staffed entirely\nby AI agents. It found a cancer therapy a\nreal pharma giant landed on months later.",
             fontsize=10.5,color=SUB,va="center",linespacing=1.5)
    fig.text(0.06,0.13,"Right: a manager agent delegating to specialist divisions and their\nswarms of worker agents.",
             fontsize=7.4,color=FAINT,linespacing=1.4)
    ax=fig.add_axes([0.58,0.1,0.40,0.82]); ax.set_xlim(0,6); ax.set_ylim(0,6); ax.axis("off")
    ax.add_patch(FancyBboxPatch((2.1,5.0),1.8,0.6,boxstyle="round,pad=0,rounding_size=0.1",fc=PURPLE,ec="white",lw=1.5,zorder=5))
    ax.text(3,5.3,"Manager",ha="center",va="center",fontsize=9,color="white",fontweight="semibold",zorder=6)
    cols=[BLUE,GOLD,AIC,BASEC]; xs=[0.5,2.0,3.5,5.0]
    for col,x in zip(cols,xs):
        ax.add_patch(FancyArrowPatch((3,4.95),(x+0.4,4.1),arrowstyle="-|>",mutation_scale=9,color=FAINT,lw=1,zorder=2))
        ax.add_patch(FancyBboxPatch((x,3.6),0.9,0.5,boxstyle="round,pad=0,rounding_size=0.08",fc=col,alpha=0.18,ec=col,lw=1.2,zorder=3))
        for k in range(15):
            ax.add_patch(Circle((x+0.1+(k%5)*0.18,3.2-(k//5)*0.25),0.055,fc=col,alpha=0.6,ec="none",zorder=3))
    fig.savefig(ROOT/"figures/cover.png",dpi=200,facecolor=fig.get_facecolor())
    print("cover.png")
if __name__=="__main__": main()
