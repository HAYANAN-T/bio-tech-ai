"""Figures for the virtual-biotech article, on the shared light theme."""
import json, sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa

R = ROOT / "results"
AIC = GOOD
BASEC = AGGRESSIVE
BLUE = RESTRAINED
PURPLE = MIXED
GOLD = PASSIVE


def save2(fig, name):
    out = ROOT / "figures" / name
    fig.savefig(out, facecolor=fig.get_facecolor()); plt.close(fig)
    return out


def fig_funnel():
    """The drug-development funnel: why 90% fail."""
    fig, gs = card(9.2, 5.0,
                   "Why making a drug is the hardest bet in business",
                   "Of candidates entering human trials, about nine in ten never reach a patient. Each failure "
                   "burns years and hundreds of millions.",
                   "Source: BIO Clinical Development Success Rates; industry analyses (2020-2025). Figure by the author.",
                   top=0.74, bottom=0.10, left=0.06, right=0.94)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 5); ax.axis("off")
    stages = [("Phase 1\nentry", 100, BLUE),
              ("Phase 2", 47, BLUE),
              ("Phase 3", 15.9, GOLD),
              ("Approval", 10, AIC),
              ("Oncology\napproval", 5.3, BASEC)]
    xw = 11.0
    for i, (label, pct, col) in enumerate(stages):
        w = xw * pct / 100
        y = 4.2 - i * 0.82
        ax.add_patch(FancyBboxPatch((6 - w/2, y - 0.32), w, 0.64,
                                    boxstyle="round,pad=0,rounding_size=0.05",
                                    fc=col, alpha=0.85, ec="white", lw=1.5, zorder=3))
        ax.text(6, y, f"{pct:g}%", ha="center", va="center", fontsize=11,
                fontweight="bold", color="white", zorder=4)
        ax.text(0.3, y, label, ha="left", va="center", fontsize=9, color=INK, linespacing=1.0)
    ax.annotate("this is the gap\nAI wants to close", xy=(6, 4.2 - 3*0.82), xytext=(9.4, 2.4),
                fontsize=9, color=AIC, fontweight="semibold", ha="center",
                arrowprops=dict(arrowstyle="-|>", color=AIC, lw=1.3))
    return save2(fig, "funnel.png")


def fig_biomarker():
    j = json.load(open(R / "vbiotech.json"))["e1"]
    auc = np.array(j["auc"])
    fig, gs = card(9.2, 5.0,
                   "A better guess is worth a fortune",
                   "When the AI's biomarker helps pick which candidates to advance, more of them succeed, even "
                   "though the signal is far from perfect.",
                   "Source: vbiotech simulation by the author, 200 trials/point. Baseline 10% matches industry data.",
                   top=0.74, bottom=0.14, left=0.08, right=0.95)
    g = GridSpec(1, 2, figure=fig, wspace=0.40, **gs)

    ax = style_ax(fig.add_subplot(g[0]), "How good the AI signal is (AUC)", "")
    panel_title(ax, "Drugs that succeed", "of those advanced")
    ax.plot(auc, np.array(j["random"]) * 100, color=BASEC, lw=2.4)
    ai = np.array(j["ai"]) * 100; ci = np.array(j["ai_ci"]) * 100
    ax.plot(auc, ai, color=AIC, lw=2.6)
    ax.fill_between(auc, ai - ci, ai + ci, color=AIC, alpha=0.15, lw=0)
    ax.text(0.515, j["random"][0]*100+0.6, "pick at random", color=BASEC, fontsize=8.6, fontweight="semibold")
    ax.text(0.515, ai[0]*100+1.0, "pick with AI", color=AIC, fontsize=8.6, fontweight="semibold")
    i70 = list(auc).index(0.7)
    ax.scatter([0.7], [ai[i70]], s=60, color=AIC, zorder=6, edgecolors=CARD, linewidths=1.5)
    ax.annotate(f"the study's result:\n{ai[i70]:.0f}% vs {j['random'][i70]*100:.0f}%", xy=(0.7, ai[i70]),
                xytext=(0.58, 6), fontsize=8.6, color=INK,
                arrowprops=dict(arrowstyle="-|>", color=FAINT, lw=1))
    ax.set_xlim(0.5, 0.8); ax.set_ylim(0, 18)
    ax.set_yticks([0, 5, 10, 15], ["0", "5%", "10%", "15%"])

    ax2 = style_ax(fig.add_subplot(g[1]), "How good the AI signal is (AUC)", "")
    panel_title(ax2, "Cost per approved drug", "$ millions, lower is better")
    ax2.plot(auc, j["cost_random"], color=BASEC, lw=2.4)
    ax2.plot(auc, j["cost_ai"], color=AIC, lw=2.6)
    ax2.text(0.515, j["cost_random"][0]+18, "random", color=BASEC, fontsize=8.6, fontweight="semibold")
    ax2.text(0.63, j["cost_ai"][3]-55, "AI", color=AIC, fontsize=8.6, fontweight="semibold")
    ax2.set_xlim(0.5, 0.8); ax2.set_ylim(0, 600)
    ax2.set_yticks([0, 200, 400, 600], ["$0", "$200M", "$400M", "$600M"])
    return save2(fig, "biomarker.png")


def fig_hierarchy():
    j = json.load(open(R / "vbiotech.json"))["e2"]
    steps = np.array(j["steps"])
    fig, gs = card(9.2, 5.0,
                   "The trick: a hierarchy, not a chain",
                   "A naive chain of agents collapses as it grows (errors multiply). A verified hierarchy of "
                   "specialists stays reliable. This is why this swarm worked.",
                   "Source: vbiotech model by the author. Chain = p^n; hierarchy = verified specialists + manager.",
                   top=0.74, bottom=0.14, left=0.09, right=0.78)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "Number of agent tasks", "Chance the whole job succeeds")
    ax.plot(steps, np.array(j["chain"]) * 100, color=BASEC, lw=2.6)
    ax.plot(steps, np.array(j["hierarchy"]) * 100, color=AIC, lw=2.6)
    end_label(ax, steps[-1], j["chain"][-1]*100, "naive chain", BASEC, dy=-2)
    end_label(ax, steps[-1], j["hierarchy"][-1]*100, "verified hierarchy", AIC, dy=4)
    ax.fill_between(steps, np.array(j["chain"])*100, np.array(j["hierarchy"])*100,
                    color=GOOD, alpha=0.06)
    ax.text(6.5, 55, "the difference\narchitecture makes", fontsize=9, color=SUB, ha="center")
    ax.set_xlim(1, 12); ax.set_ylim(0, 100)
    ax.set_yticks([0, 25, 50, 75, 100], ["0", "25%", "50%", "75%", "100%"])
    return save2(fig, "hierarchy.png")


def fig_speed():
    j = json.load(open(R / "vbiotech.json"))["e3"]
    fig, gs = card(9.2, 4.2,
                   "Fifty-five thousand trials, read in a week",
                   "The same evidence review that would take one human analyst a lifetime, the agent swarm did in days.",
                   "Source: vbiotech throughput estimate by the author, from the study's reported scale.",
                   top=0.78, bottom=0.12, left=0.07, right=0.93)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 4); ax.axis("off")
    # two bars on a log-ish visual scale
    ax.text(0.3, 3.3, "AI agent swarm", fontsize=11, color=AIC, fontweight="semibold")
    ax.add_patch(FancyBboxPatch((3.0, 3.05), 0.35, 0.5, boxstyle="round,pad=0,rounding_size=0.05",
                                fc=AIC, ec="none"))
    ax.text(3.5, 3.3, "7 days", fontsize=11, color=INK, va="center", fontweight="semibold")
    ax.text(0.3, 1.8, "One human analyst", fontsize=11, color=BASEC, fontweight="semibold")
    ax.add_patch(FancyBboxPatch((3.0, 1.55), 8.4, 0.5, boxstyle="round,pad=0,rounding_size=0.05",
                                fc=BASEC, alpha=0.85, ec="none"))
    ax.text(11.5, 1.8, f"~{j['human_years_one_analyst']:.0f} years", fontsize=11, color=INK,
            va="center", ha="right", fontweight="semibold")
    ax.text(6, 0.6, f"about {j['speedup']:,.0f}x faster  -  {j['trials']:,} clinical trials analyzed",
            ha="center", fontsize=10, color=PURPLE, fontweight="semibold")
    return save2(fig, "speed.png")


def fig_org():
    """The virtual biotech org chart."""
    fig, gs = card(9.2, 5.0,
                   "A company with 37,000 workers and no people",
                   "The virtual biotech copies the shape of a real drug company: a manager agent directs "
                   "specialist divisions that work in parallel.",
                   "Source: structure from Zhang & Zou et al., Science (2026). Diagram by the author.",
                   top=0.78, bottom=0.08, left=0.05, right=0.95)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 5); ax.axis("off")
    # CSO
    ax.add_patch(FancyBboxPatch((4.6, 4.0), 2.8, 0.8, boxstyle="round,pad=0,rounding_size=0.08",
                                fc=PURPLE, alpha=0.9, ec="white", lw=1.5, zorder=4))
    ax.text(6, 4.4, "Chief Scientist agent", ha="center", va="center", fontsize=10.5,
            fontweight="semibold", color="white", zorder=5)
    ax.text(6, 3.65, "receives the question, delegates, and verifies the answers",
            ha="center", fontsize=8, color=SUB)
    divs = [("Target\ndiscovery", BLUE), ("Safety\nassessment", GOLD),
            ("Drug\ndelivery", AIC), ("Clinical trial\nanalysis", BASEC)]
    xs = [1.6, 4.0, 6.4, 8.8]
    for (name, col), x in zip(divs, xs):
        ax.add_patch(FancyArrowPatch((6, 3.95), (x + 0.9, 2.95), arrowstyle="-|>",
                                     mutation_scale=11, color=FAINT, lw=1.2, zorder=2))
        ax.add_patch(FancyBboxPatch((x, 2.2), 1.8, 0.75, boxstyle="round,pad=0,rounding_size=0.06",
                                    fc=col, alpha=0.16, ec=col, lw=1.3, zorder=3))
        ax.text(x + 0.9, 2.57, name, ha="center", va="center", fontsize=8.6,
                fontweight="semibold", color=INK, zorder=4)
        # worker dots under each division
        for k in range(12):
            ax.add_patch(Circle((x + 0.2 + (k % 6) * 0.28, 1.7 - (k // 6) * 0.28), 0.07,
                                fc=col, alpha=0.6, ec="none", zorder=3))
    ax.text(6, 0.9, "...up to 37,000 specialist agents working in parallel",
            ha="center", fontsize=9.5, color=PURPLE, fontweight="semibold")
    return save2(fig, "org.png")


if __name__ == "__main__":
    for f in [fig_funnel, fig_biomarker, fig_hierarchy, fig_speed, fig_org]:
        print(f())
