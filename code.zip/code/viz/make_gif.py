"""Animated: the agent swarm fanning out across thousands of trials in parallel."""
import sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.patches import FancyBboxPatch, Circle, FancyArrowPatch
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa
PURPLE=MIXED; BLUE=RESTRAINED; AIC=GOOD; GOLD=PASSIVE; BASEC=AGGRESSIVE

def main():
    fig=plt.figure(figsize=(8.2,4.8),facecolor=BG,dpi=100)
    fig.text(0.06,0.93,"How 37,000 agents read 55,984 trials in a week",fontsize=14.5,fontweight="semibold",color=INK)
    fig.text(0.06,0.872,"One manager agent delegates; thousands of specialists work in parallel; results flow back up.",fontsize=9.2,color=SUB)
    fig.text(0.06,0.05,"Source: structure from Zhang & Zou et al., Science (2026). Illustration by the author.",fontsize=8,color=FAINT)
    ax=fig.add_axes([0.04,0.12,0.92,0.72]); ax.set_xlim(0,12); ax.set_ylim(0,6); ax.axis("off")
    # manager
    mgr=FancyBboxPatch((5.1,5.0),1.8,0.7,boxstyle="round,pad=0,rounding_size=0.08",fc=PURPLE,ec="white",lw=1.5,zorder=5)
    ax.add_patch(mgr); ax.text(6,5.35,"Manager",ha="center",va="center",fontsize=9.5,color="white",fontweight="semibold",zorder=6)
    # grid of worker dots (the trials being processed)
    NX,NY=28,7
    xs=np.linspace(0.6,11.4,NX); ys=np.linspace(0.5,3.6,NY)
    dots=[]
    for yi in ys:
        for xi in xs:
            c=Circle((xi,yi),0.11,fc="#D9E0E9",ec="none",zorder=3); ax.add_patch(c); dots.append(c)
    order=np.random.default_rng(1).permutation(len(dots))
    counter=fig.text(0.5,0.09,"",ha="center",fontsize=11,color=PURPLE,fontweight="semibold")
    # delegation arrows (appear early)
    arrows=[]
    for tx in [1.5,4.0,8.0,10.5]:
        a=FancyArrowPatch((6,4.95),(tx,3.8),arrowstyle="-|>",mutation_scale=10,color=FAINT,lw=1.1,alpha=0,zorder=2)
        ax.add_patch(a); arrows.append(a)

    frames=48
    def update(f):
        # phase 1: arrows fan out; phase 2: dots turn processed
        for a in arrows: a.set_alpha(min(1.0, f/6) if f<12 else max(0,1-(f-12)/6))
        done=int(len(dots)* min(max((f-4)/36,0),1))
        for i in range(len(dots)):
            if i<done:
                # colour by a fake "division"
                col=[BLUE,GOLD,AIC,BASEC][order[i]%4]
                dots[order[i]].set_facecolor(col)
        n_trials=int(55984* min(max((f-4)/36,0),1))
        counter.set_text(f"{n_trials:,} trials analyzed" + ("   done" if done>=len(dots) else ""))
        return []
    anim=FuncAnimation(fig,update,frames=frames,blit=False)
    out=ROOT/"figures/anim_swarm.gif"
    anim.save(out,writer=PillowWriter(fps=12),savefig_kwargs={"facecolor":BG})
    print(out)

if __name__=="__main__":
    main()
